#include "CloudSpeechClient.h"
#include "network_param.h"
#include <base64.h>
#include <ArduinoJson.h>
#define USE_SERIAL Serial
#define USE_SERIAL Serial2
#include <Arduino.h>
#include <HTTPClient.h>
//#include <HardwareSerial.h>

//#define uart_en 15
 //#define led_3 4
#define led_1 15
#define led_2 2
#define RXp2 16
#define TXp2 17

 
 
//#include <SoftwareSerial.h>
////SoftwareSerial (D4, D2);
//const char* chatgpt_token = "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";

CloudSpeechClient::CloudSpeechClient(Authentication authentication) {
  this->authentication = authentication;
  WiFi.begin(ssid, password);
 //  while (WiFi.status() == WL_CONNECTED){ digitalWrite(led_3,1);}
  while (WiFi.status() != WL_CONNECTED) delay(1000);
  client.setCACert(root_ca);
  if (!client.connect(server, 443)) Serial.println("Connection failed!"); /*digitalWrite(led_3,1);*/digitalWrite(led_1,0);digitalWrite(led_2,0);
}


String ans;

CloudSpeechClient::~CloudSpeechClient() {
  client.stop();
  WiFi.disconnect();
}

void CloudSpeechClient::PrintHttpBody2(Audio* audio)
{
  String enc = base64::encode(audio->paddedHeader, sizeof(audio->paddedHeader));
  enc.replace("\n", "");  // delete last "\n"
  client.print(enc);      // HttpBody2
  char** wavData = audio->wavData;
  for (int j = 0; j < audio->wavDataSize / audio->dividedWavDataSize; ++j) {
    enc = base64::encode((byte*)wavData[j], audio->dividedWavDataSize);
    enc.replace("\n", "");// delete last "\n"
    client.print(enc);    // HttpBody2
  }
}


void CloudSpeechClient::Transcribe(Audio* audio) {
 //////////////////////////////////////////////////////////
 ...
 ...
 ... 
 //////////////////////////////////////////////////////////
/*
pinMode(LED_BUILTIN,OUTPUT);
if(strstr(chatgpt_Q, "light on")){
  digitalWrite(LED_BUILTIN,HIGH);
  Serial.println("Light's On");
  digitalWrite(15, LOW);
delay(1);
Serial2.println("Turning Light on");
digitalWrite(led_1,1);
//digitalWrite(led_3,0);
digitalWrite(led_2,1);
//digitalWrite(uart_en,HIGH);
  Serial.print("To ask again");
  }
if(strstr(chatgpt_Q, "light off")){
  digitalWrite(LED_BUILTIN,LOW);
  Serial.println("Light's Off");
  digitalWrite(15, LOW);
delay(1);
Serial2.println("Turning Light off");
digitalWrite(led_1,1);
digitalWrite(led_2,1);
//digitalWrite(uart_en,HIGH);
  Serial.print("To ask again");
  }  
 if(strstr(chatgpt_Q, "blink on")){
  HTTPClient http;

        USE_SERIAL.print("[HTTP] begin...\n");
        // configure traged server and url
        //http.begin("https://www.howsmyssl.com/a/check", ca); //HTTPS
        http.begin("http://example.com/index.html"); //HTTP

        USE_SERIAL.print("[HTTP] GET...\n");
        // start connection and send HTTP header
        int httpCode = http.GET();

        // httpCode will be negative on error
        if(httpCode > 0) {
            // HTTP header has been send and Server response header has been handled
            USE_SERIAL.printf("[HTTP] GET... code: %d\n", httpCode);

            // file found at server
            if(httpCode == HTTP_CODE_OK|| httpCode == HTTP_CODE_MOVED_PERMANENTLY) {
                String payload = http.getString();
                USE_SERIAL.println(payload);
            }
        } else {
            USE_SERIAL.printf("[HTTP] GET... failed, error: %s\n", http.errorToString(httpCode).c_str());
        }

        http.end();
  } 
 else if(strstr(chatgpt_Q, "light on")==0 && strstr(chatgpt_Q, "light off") == 0 && strstr(chatgpt_Q, "blink on") ==0 ){
  Serial.println("Asking Chat GPT");
  HTTPClient https;
  client.setInsecure();

    Serial.print("[HTTPS] begin...\n");
    if (https.begin("https://api.openai.com/v1/completions")) {  // HTTPS
      
      https.addHeader("Content-Type", "application/json"); 
      String token_key = String("Bearer ") + chatgpt_token;
      https.addHeader("Authorization", token_key);
      
      String payload = String("{\"model\": \"text-davinci-003\", \"prompt\": ") +"\""+ chatgpt_Q +"\"" + String(", \"temperature\": 0.2, \"max_tokens\": 40}"); //Instead of TEXT as Payload, can be JSON as Paylaod
      
      Serial.print("[HTTPS] GET...\n");
      
      // start connection and send HTTP header
      int httpCode = https.POST(payload);

      // httpCode will be negative on error      
      // file found at server
      if (httpCode == HTTP_CODE_OK || httpCode == HTTP_CODE_MOVED_PERMANENTLY) {
        String payload = https.getString();
        Serial.println(payload);
       // Serial2.println(payload);
        //////////////////////////////////////////////////
        StaticJsonDocument<2000> doc2;

DeserializationError error = deserializeJson(doc2, payload);

if (error) {
  Serial.print("deserializeJson() failed: ");
  Serial.println(error.c_str());
  return;

}
JsonObject choices_0 = doc2["choices"][0];
const char* only_ans = choices_0["text"];
Serial.println("Only ans:-");Serial.print(only_ans);
//Serial2.print(only_ans);
digitalWrite(led_1,1);
digitalWrite(led_2,1);
//digitalWrite(uart_en, LOW);
delay(1);

//digitalWrite(uart_en,HIGH);
        /////////////////////////////////////////////////////////
      }
      else {
        Serial.printf("[HTTPS] GET... failed, error: %s\n", https.errorToString(httpCode).c_str());
      }
      https.end();
    }
    else {
      Serial.printf("[HTTPS] Unable to connect\n");
    }

  Serial.println("To ask again");
  //delay(10000);
  
  } 
*/



///////////////////////////////////////////////////////////
/*

   
  */
}
