#ifndef _NETWORK_PARAM_H
#define _NETWORK_PARAM_H

const char *ssid = "Your Wifi SSID";
const char *password = "Your Wifi Password";
const char *server = "speech.googleapis.com";

// Your SSL Sertificate
const char *root_ca =
"-----BEGIN CERTIFICATE-----\n"
"MIIFYjCCBEqgAwIBAgIQd70NbNs2+RrqIQ/E8FjTDTANBgkqhkiG9w0BAQsFADBX\n"
...
...
...
"d0lIKO2d1xozclOzgjXPYovJJIultzkMu34qQb9Sz/yilrbCgj8=\n"
"-----END CERTIFICATE-----\n";
// It is also possible to use "API Key" instead of "Access Token". It doesn't have time limit.
const String ApiKey = "Your Google Cloud API Key";

#endif  // _NETWORK_PARAM_H
